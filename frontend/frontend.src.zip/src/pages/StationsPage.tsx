import React, { useState, useEffect } from 'react';
import { useStationStore } from '@/stores/stationStore';
import { api } from '@/services/api';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Plus, Edit, Trash2, MapPin, CheckCircle, XCircle, Loader2 } from 'lucide-react';
import toast from 'react-hot-toast';

export const StationsPage: React.FC = () => {
  const { stations, activeStation, setStations, setActiveStation, isLoading, setIsLoading } = useStationStore();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingStation, setEditingStation] = useState<any>(null);
  const [formData, setFormData] = useState({
    name: '',
    code: '',
    wmoId: '',
    latitude: '',
    longitude: '',
    elevation: '',
    terrainType: 'HIGHLANDS',
    topographyDescription: '',
    runwayLength: '',
    runwayOrientation: '',
    runwaySurface: '',
    category: 'DOMESTIC',
  });

  useEffect(() => {
    fetchStations();
  }, []);

  const fetchStations = async () => {
    setIsLoading(true);
    try {
      const response = await api.getStations();
      setStations(response.data.data);
    } catch (error) {
      console.error('Failed to fetch stations:', error);
      toast.error('Failed to load stations');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = {
        ...formData,
        latitude: parseFloat(formData.latitude),
        longitude: parseFloat(formData.longitude),
        elevation: parseFloat(formData.elevation),
        runwayLength: formData.runwayLength ? parseFloat(formData.runwayLength) : undefined,
      };

      if (editingStation) {
        await api.updateStation(editingStation.id, data);
        toast.success('Station updated successfully');
      } else {
        await api.createStation(data);
        toast.success('Station created successfully');
      }
      
      await fetchStations();
      setIsDialogOpen(false);
      resetForm();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to save station');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this station?')) return;
    
    try {
      await api.deleteStation(id);
      toast.success('Station deleted successfully');
      await fetchStations();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to delete station');
    }
  };

  const handleSetActive = async (id: string) => {
    try {
      await api.setActiveStation(id);
      const station = stations.find(s => s.id === id);
      setActiveStation(station || null);
      toast.success('Active station updated');
      await fetchStations();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to set active station');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      code: '',
      wmoId: '',
      latitude: '',
      longitude: '',
      elevation: '',
      terrainType: 'HIGHLANDS',
      topographyDescription: '',
      runwayLength: '',
      runwayOrientation: '',
      runwaySurface: '',
      category: 'DOMESTIC',
    });
    setEditingStation(null);
  };

  const openEditDialog = (station: any) => {
    setEditingStation(station);
    setFormData({
      name: station.name,
      code: station.code,
      wmoId: station.wmoId || '',
      latitude: station.latitude.toString(),
      longitude: station.longitude.toString(),
      elevation: station.elevation.toString(),
      terrainType: station.terrainType,
      topographyDescription: station.topographyDescription,
      runwayLength: station.runwayLength?.toString() || '',
      runwayOrientation: station.runwayOrientation || '',
      runwaySurface: station.runwaySurface || '',
      category: station.category,
    });
    setIsDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Stations & Airports</h1>
          <p className="text-muted-foreground">
            Manage all airport and airstrip configurations
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => { resetForm(); setIsDialogOpen(true); }}>
              <Plus className="mr-2 h-4 w-4" />
              Add Station
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingStation ? 'Edit Station' : 'Add New Station'}</DialogTitle>
              <DialogDescription>
                Enter the station details below. All fields with * are required.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Station Name *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="code">Station Code *</Label>
                    <Input
                      id="code"
                      value={formData.code}
                      onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                      required
                      placeholder="e.g., HKJK"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="wmoId">WMO ID</Label>
                    <Input
                      id="wmoId"
                      value={formData.wmoId}
                      onChange={(e) => setFormData({ ...formData, wmoId: e.target.value })}
                      placeholder="e.g., 63740"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">Category *</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => setFormData({ ...formData, category: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="INTERNATIONAL">International</SelectItem>
                        <SelectItem value="DOMESTIC">Domestic</SelectItem>
                        <SelectItem value="AERODROME">Aerodrome</SelectItem>
                        <SelectItem value="AIRSTRIP">Airstrip</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="latitude">Latitude *</Label>
                    <Input
                      id="latitude"
                      type="number"
                      step="any"
                      value={formData.latitude}
                      onChange={(e) => setFormData({ ...formData, latitude: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="longitude">Longitude *</Label>
                    <Input
                      id="longitude"
                      type="number"
                      step="any"
                      value={formData.longitude}
                      onChange={(e) => setFormData({ ...formData, longitude: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="elevation">Elevation (ft) *</Label>
                    <Input
                      id="elevation"
                      type="number"
                      step="any"
                      value={formData.elevation}
                      onChange={(e) => setFormData({ ...formData, elevation: e.target.value })}
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="terrainType">Terrain Type *</Label>
                  <Select
                    value={formData.terrainType}
                    onValueChange={(value) => setFormData({ ...formData, terrainType: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select terrain type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="HIGHLANDS">Highlands</SelectItem>
                      <SelectItem value="COASTAL">Coastal</SelectItem>
                      <SelectItem value="LAKE_REGION">Lake Region</SelectItem>
                      <SelectItem value="SEMI_ARID">Semi-Arid</SelectItem>
                      <SelectItem value="VALLEY_MOUNTAIN">Valley/Mountain</SelectItem>
                      <SelectItem value="PLAINS">Plains</SelectItem>
                      <SelectItem value="DESERT">Desert</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="topographyDescription">Topography Description *</Label>
                  <Input
                    id="topographyDescription"
                    value={formData.topographyDescription}
                    onChange={(e) => setFormData({ ...formData, topographyDescription: e.target.value })}
                    required
                  />
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="runwayLength">Runway Length (ft)</Label>
                    <Input
                      id="runwayLength"
                      type="number"
                      step="any"
                      value={formData.runwayLength}
                      onChange={(e) => setFormData({ ...formData, runwayLength: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="runwayOrientation">Runway Orientation</Label>
                    <Input
                      id="runwayOrientation"
                      value={formData.runwayOrientation}
                      onChange={(e) => setFormData({ ...formData, runwayOrientation: e.target.value })}
                      placeholder="e.g., 06/24"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="runwaySurface">Runway Surface</Label>
                    <Input
                      id="runwaySurface"
                      value={formData.runwaySurface}
                      onChange={(e) => setFormData({ ...formData, runwaySurface: e.target.value })}
                      placeholder="e.g., Asphalt"
                    />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  {editingStation ? 'Update' : 'Create'}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Stations</CardTitle>
          <CardDescription>
            {stations.length} stations configured in the system
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Code</TableHead>
                  <TableHead>WMO ID</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Terrain</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {stations.map((station) => (
                  <TableRow key={station.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        {station.name}
                      </div>
                    </TableCell>
                    <TableCell>{station.code}</TableCell>
                    <TableCell>{station.wmoId || '-'}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{station.category}</Badge>
                    </TableCell>
                    <TableCell>{station.terrainType}</TableCell>
                    <TableCell>
                      {station.isActive ? (
                        <Badge className="bg-green-500 hover:bg-green-600">
                          <CheckCircle className="mr-1 h-3 w-3" />
                          Active
                        </Badge>
                      ) : (
                        <Badge variant="secondary">
                          <XCircle className="mr-1 h-3 w-3" />
                          Inactive
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        {!station.isActive && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleSetActive(station.id)}
                          >
                            Set Active
                          </Button>
                        )}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openEditDialog(station)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDelete(station.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                {stations.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                      No stations found. Click "Add Station" to create one.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};